# 프로젝트 윈드리스 팬 아카이브 (비공식)

이영도 『눈물을 마시는 새』 × 크래프톤 몬트리올 '프로젝트 윈드리스' 비공식 팬 제작물.

- `index.html` — 팬 아카이브 (종족 카드, 종족 테스트, 소개 영상)
- `lab.html` — 윈드리스 필드 랩 (아카이브에서 서랍으로 열림)
- `intro.mp4`, `poster.jpg`, `bgm.mp3` — 소개 영상, 포스터, 배경음악

GitHub Pages: Settings → Pages → Branch `main` / root 로 켜면 `index.html`이 바로 열립니다.
